import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { expect, userEvent } from "storybook/test";
import { FilterListEditor } from "../dist/index.js";
import "../dist/styles.css";
const meta = {
  title: "Extension UI/Filter list editor",
  component: FilterListEditor,
  args: {
    inputLabel: "Title keyword",
    placeholder: "e.g. Graduate, Java",
    emptyText: "No title keywords yet.",
  },
} satisfies Meta<typeof FilterListEditor>;
export default meta;
type Story = StoryObj;
export const Interactive: Story = {
  render: function Editor(args) {
    const [values, setValues] = useState(["Ruby", "Graduate"]);
    return (
      <FilterListEditor
        {...args}
        values={values}
        onAdd={(value) => setValues([...values, value])}
        onRemove={(value) => setValues(values.filter((v) => v !== value))}
      />
    );
  },
  play: async ({ canvas }) => {
    await userEvent.type(canvas.getByRole("textbox"), "Java{Enter}");
    await expect(
      canvas.getByRole("button", { name: "Remove Java" }),
    ).toBeInTheDocument();
    await userEvent.click(canvas.getByRole("button", { name: "Remove Java" }));
    await expect(
      canvas.queryByRole("button", { name: "Remove Java" }),
    ).not.toBeInTheDocument();
  },
};
export const Empty: Story = {
  render: (args) => (
    <FilterListEditor
      {...args}
      values={[]}
      onAdd={() => {}}
      onRemove={() => {}}
    />
  ),
};
export const LongValues: Story = {
  render: (args) => (
    <div style={{ width: 280 }}>
      <FilterListEditor
        {...args}
        values={[
          "A very long custom title filter that must wrap in a narrow extension popup",
        ]}
        onAdd={() => {}}
        onRemove={() => {}}
      />
    </div>
  ),
};
