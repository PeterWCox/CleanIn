import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, fn, userEvent } from "storybook/test";
import { ExtensionHeader } from "../dist/index.js";
import "../dist/styles.css";
const meta = {
  title: "Extension UI/Extension header",
  component: ExtensionHeader,
  args: {
    branding: {
      name: "LinkedIn Developer Jobs Filter",
      subtitle: "Office Attendance and developer job filters",
    },
    version: "4.4.0",
    beta: true,
  },
} satisfies Meta<typeof ExtensionHeader>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Summary: Story = {};
export const BackNavigation: Story = {
  args: { onBack: fn(), backLabel: "Back to job summary" },
  play: async ({ canvas, args }) => {
    await userEvent.click(
      canvas.getByRole("button", { name: "Back to job summary" }),
    );
    await expect(args.onBack).toHaveBeenCalledOnce();
  },
};
export const Narrow: Story = {
  ...BackNavigation,
  decorators: [
    (Story) => (
      <div style={{ width: 320 }}>
        <Story />
      </div>
    ),
  ],
};
