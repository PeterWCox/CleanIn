import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { expect, userEvent } from "storybook/test";
import { Button, Input, Switch, ShowHide } from "../dist/index.js";
import "../dist/styles.css";
const meta = {
  title: "Extension UI/Controls",
  component: Button,
} satisfies Meta<typeof Button>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Buttons: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 12 }}>
      <Button>Continue</Button>
      <Button variant="outline">Secondary</Button>
      <Button variant="ghost" size="small">
        Dismiss
      </Button>
      <Button size="icon" aria-label="Add">
        +
      </Button>
      <Button disabled>Disabled</Button>
    </div>
  ),
};
export const InputsAndSwitches: Story = {
  render: function Controls() {
    const [checked, setChecked] = useState(false);
    return (
      <div style={{ display: "grid", gap: 12, maxWidth: 360 }}>
        <Input aria-label="Search" placeholder="Search filters" />
        <Switch
          label="Enable filtering"
          checked={checked}
          onCheckedChange={setChecked}
        />
        <Switch size="lg" checked aria-label="Large switch" />
        <Switch disabled aria-label="Disabled switch" />
      </div>
    );
  },
  play: async ({ canvas }) => {
    await userEvent.click(
      canvas.getByRole("switch", { name: "Enable filtering" }),
    );
    await expect(
      canvas.getByRole("switch", { name: "Enable filtering" }),
    ).toHaveAttribute("aria-checked", "true");
  },
};
export const Visibility: Story = {
  render: function Visibility() {
    const [hidden, setHidden] = useState(false);
    return (
      <ShowHide
        label="Remote"
        hidden={hidden}
        onChange={() => setHidden(!hidden)}
      />
    );
  },
  play: async ({ canvas }) => {
    await userEvent.click(canvas.getByRole("button", { name: "Hide Remote" }));
    await expect(
      canvas.getByRole("button", { name: "Hide Remote" }),
    ).toHaveAttribute("aria-pressed", "true");
  },
};
