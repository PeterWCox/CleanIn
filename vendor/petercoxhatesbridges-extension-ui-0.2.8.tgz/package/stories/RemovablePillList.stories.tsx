import * as React from "react";
import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, userEvent } from "storybook/test";
import { RemovablePillList } from "../dist/index.js";
import "../dist/styles.css";
const meta = {
  title: "Extension UI/Removable pill list",
  component: RemovablePillList,
} satisfies Meta<typeof RemovablePillList>;
export default meta;
type Story = StoryObj<typeof meta>;
export const WrappingAndRemoval: Story = {
  args: {
    values: [
      "Graduate",
      "Junior",
      "Java",
      "PHP",
      "Recruitment Consultant",
      "An unusually long title keyword that wraps within a narrow panel",
    ],
    onRemove: () => {},
  },
  render: function Pills(args) {
    const [values, setValues] = useState(args.values);
    return (
      <div style={{ width: 280 }}>
        <RemovablePillList
          {...args}
          values={values}
          onRemove={(value) =>
            setValues(values.filter((item) => item !== value))
          }
        />
      </div>
    );
  },
  play: async ({ canvas }) => {
    await userEvent.click(canvas.getByRole("button", { name: "Remove Java" }));
    await expect(
      canvas.queryByRole("button", { name: "Remove Java" }),
    ).not.toBeInTheDocument();
    await expect(
      canvas.getByRole("button", { name: "Remove PHP" }),
    ).toBeInTheDocument();
  },
};
export const Empty: Story = {
  args: { values: [], onRemove: () => {}, emptyText: "No filters yet." },
};
