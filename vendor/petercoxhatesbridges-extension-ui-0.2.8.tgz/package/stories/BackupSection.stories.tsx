import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, fn, userEvent } from "storybook/test";
import { BackupSection, createExtensionBackup } from "../dist/index.js";
import "../dist/styles.css";
const meta = {
  title: "Extension UI/Backup and restore",
  component: BackupSection,
  args: {
    extensionId: "example",
    extensionName: "Example",
    extensionVersion: "1.0.0",
    exportData: async () => ({ enabled: true, filters: ["Graduate"] }),
    importData: async () => {},
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 400, padding: 16, fontFamily: "system-ui" }}>
        <Story />
      </div>
    ),
  ],
} satisfies Meta<typeof BackupSection>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Ready: Story = {
  play: async ({ canvas, canvasElement }) => {
    await expect(
      canvas.getByRole("button", { name: "Export backup" }),
    ).toBeVisible();
    await expect(
      canvas.getByRole("button", { name: "Import backup" }),
    ).toBeVisible();
    await expect(
      canvasElement.querySelectorAll(".ext-settings-row-icon svg"),
    ).toHaveLength(2);
    await expect(canvas.queryByRole("switch")).not.toBeInTheDocument();
  },
};
const backup = () =>
  new File(
    [
      JSON.stringify(
        createExtensionBackup("example", "1.0.0", { enabled: false }),
      ),
    ],
    "example-backup.json",
    { type: "application/json" },
  );
export const ImmediateRestore: Story = {
  args: { importData: fn(async () => {}) },
  play: async ({ canvas, args }) => {
    await userEvent.upload(
      canvas.getByLabelText("Choose backup file"),
      backup(),
    );
    await expect(await canvas.findByText("Backup restored.")).toBeVisible();
    await expect(args.importData).toHaveBeenCalledWith({ enabled: false });
    await expect(
      canvas.queryByRole("group", { name: "Confirm backup restore" }),
    ).not.toBeInTheDocument();
  },
};
export const WrongExtension: Story = {
  args: { importData: fn(async () => {}) },
  play: async ({ canvas, args }) => {
    await userEvent.upload(
      canvas.getByLabelText("Choose backup file"),
      new File(
        [JSON.stringify(createExtensionBackup("another", "1", {}))],
        "wrong.json",
        { type: "application/json" },
      ),
    );
    await expect(
      await canvas.findByText(/belongs to a different extension/),
    ).toBeVisible();
    await expect(args.importData).not.toHaveBeenCalled();
  },
};
export const FailedRestore: Story = {
  args: {
    importData: async () => {
      throw new Error("Storage is unavailable.");
    },
  },
  play: async ({ canvas }) => {
    await userEvent.upload(
      canvas.getByLabelText("Choose backup file"),
      backup(),
    );
    await expect(
      await canvas.findByText(/Storage is unavailable/),
    ).toBeVisible();
  },
};
