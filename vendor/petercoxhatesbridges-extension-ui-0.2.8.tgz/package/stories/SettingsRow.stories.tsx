import * as React from "react";
import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, userEvent } from "storybook/test";
import { SettingsRow, Switch, ShowHide } from "../dist/index.js";
import "../dist/styles.css";
const meta = {
  title: "Extension UI/Settings row",
  component: SettingsRow,
} satisfies Meta<typeof SettingsRow>;
export default meta;
type Story = StoryObj;
export const SwitchControl: Story = {
  render: function Row() {
    const [checked, setChecked] = useState(true);
    return (
      <div style={{ maxWidth: 400, fontFamily: "system-ui" }}>
        <SettingsRow
          label="Hide suggested posts"
          description="Choose which content appears in your feed."
        >
          <Switch
            checked={checked}
            onCheckedChange={setChecked}
            aria-label="Hide suggested posts"
          />
        </SettingsRow>
      </div>
    );
  },
  play: async ({ canvas }) => {
    await userEvent.click(canvas.getByRole("switch"));
    await expect(canvas.getByRole("switch")).toHaveAttribute(
      "aria-checked",
      "false",
    );
  },
};
export const VisibilityControl: Story = {
  render: function Row() {
    const [hidden, setHidden] = useState(false);
    return (
      <div style={{ maxWidth: 400, fontFamily: "system-ui" }}>
        <SettingsRow label="Remote">
          <ShowHide
            label="Remote"
            hidden={hidden}
            onChange={() => setHidden(!hidden)}
          />
        </SettingsRow>
      </div>
    );
  },
};
