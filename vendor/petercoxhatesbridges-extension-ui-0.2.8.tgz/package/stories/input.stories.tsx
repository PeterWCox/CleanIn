import * as React from "react";
import "../dist/styles.css";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { Input } from "../dist/index.js";

const meta = { title: "Extension UI/input" } satisfies Meta<typeof Input>;
export default meta;
type Story = StoryObj<typeof meta>;

export const States: Story = {
  render: () => (
    <div style={{ display: "grid", gap: 12, maxWidth: 360 }}>
      <Input placeholder="Search jobs" aria-label="Search jobs" />
      <Input value="TypeScript" readOnly aria-label="Entered value" />
      <Input placeholder="Disabled" disabled aria-label="Disabled input" />
    </div>
  ),
};
