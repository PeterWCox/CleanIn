import * as React from "react";
import "../dist/styles.css";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { Switch } from "../dist/index.js";

const meta = { title: "Extension UI/switch" } satisfies Meta<typeof Switch>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Interactive: Story = {
  render: () => {
    const [checked, setChecked] = useState(false);
    return (
      <Switch
        checked={checked}
        onCheckedChange={setChecked}
        aria-label="Enable setting"
      />
    );
  },
};

export const WithLabel: Story = {
  render: () => (
    <Switch
      aria-label="Enable notifications"
      label="Enable notifications"
      checked
    />
  ),
};
