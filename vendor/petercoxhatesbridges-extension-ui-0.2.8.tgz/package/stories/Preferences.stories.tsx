import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { expect, userEvent } from "storybook/test";
import {
  PreferencesShell,
  PreferencesHeader,
  PreferencesLayout,
  PreferencesNavigation,
  PreferencesContent,
  PreferencesFooter,
  TabsList,
  TabsTrigger,
  TabsContent,
  FilterListEditor,
} from "../dist/index.js";
import "../dist/styles.css";
const meta = {
  title: "Extension UI/Preferences",
  parameters: { layout: "fullscreen" },
} satisfies Meta;
export default meta;
type Story = StoryObj<typeof meta>;
export const BrandedLayout: Story = {
  render: function Layout() {
    const [values, setValues] = useState(["Graduate"]);
    return (
      <PreferencesShell
        defaultValue="filters"
        style={{ height: 600, width: 480, maxWidth: "100%" }}
      >
        <PreferencesHeader>
          <div className="brand-wordmark">
            <strong>My extension</strong>
            <span>Custom branding slot</span>
          </div>
        </PreferencesHeader>
        <PreferencesLayout>
          <PreferencesNavigation>
            <TabsList
              className="preferences-tabs-list"
              aria-label="Preference sections"
            >
              <TabsTrigger className="preferences-tab" value="filters">
                Filters
              </TabsTrigger>
              <TabsTrigger className="preferences-tab" value="settings">
                Settings
              </TabsTrigger>
            </TabsList>
          </PreferencesNavigation>
          <PreferencesContent>
            <TabsContent value="filters">
              <div className="preferences-content-heading">
                <h1>Filters</h1>
              </div>
              <p className="preferences-info">
                Hide jobs matching these title keywords.
              </p>
              <FilterListEditor
                values={values}
                inputLabel="Title keyword"
                onAdd={(value) => setValues([...values, value])}
                onRemove={(value) =>
                  setValues(values.filter((v) => v !== value))
                }
              />
            </TabsContent>
            <TabsContent value="settings">
              Extension-specific settings
            </TabsContent>
          </PreferencesContent>
          <PreferencesFooter>Extension-specific links</PreferencesFooter>
        </PreferencesLayout>
      </PreferencesShell>
    );
  },
  play: async ({ canvas }) => {
    await userEvent.click(canvas.getByRole("tab", { name: "Settings" }));
    await expect(canvas.getByRole("tabpanel")).toHaveTextContent(
      "Extension-specific settings",
    );
  },
};
