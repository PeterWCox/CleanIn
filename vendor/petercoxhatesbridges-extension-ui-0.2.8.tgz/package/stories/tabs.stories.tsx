import * as React from "react";
import "../dist/styles.css";
import { expect, userEvent } from "storybook/test";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../dist/index.js";

const meta = { title: "Extension UI/tabs" } satisfies Meta;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: () => (
    <Tabs defaultValue="signals" style={{ maxWidth: 420 }}>
      <TabsList>
        <TabsTrigger value="signals">Signals</TabsTrigger>
        <TabsTrigger value="settings">Settings</TabsTrigger>
      </TabsList>
      <TabsContent value="signals">Signals found in this job.</TabsContent>
      <TabsContent value="settings">Extension preferences.</TabsContent>
    </Tabs>
  ),
  play: async ({ canvas }) => {
    await userEvent.click(canvas.getByRole("tab", { name: "Signals" }));
    await userEvent.keyboard("{ArrowRight}");
    await expect(canvas.getByRole("tab", { name: "Settings" })).toHaveAttribute(
      "aria-selected",
      "true",
    );
  },
};
