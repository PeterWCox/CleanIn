import * as React from "react";
import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, userEvent } from "storybook/test";
import {
  ExtensionShell,
  TabsContent,
  FilterListEditor,
  SettingsSection,
  SaveStatus,
  InfoBanner,
  Button,
} from "../dist/index.js";
import "../dist/styles.css";
const meta = {
  title: "Extension UI/Extension shell",
  component: ExtensionShell,
  parameters: { layout: "fullscreen" },
} satisfies Meta<typeof ExtensionShell>;
export default meta;
type Story = StoryObj;
const tabs = [
  {
    id: "filters",
    label: "Filters",
    description: "Hide jobs matching your custom filters.",
    icon: <span aria-hidden="true">T</span>,
  },
  {
    id: "settings",
    label: "Settings",
    secondary: true,
    icon: <span aria-hidden="true">⚙</span>,
  },
];
export const ConfiguredShell: Story = {
  render: function Shell() {
    const [active, setActive] = useState("filters");
    const [values, setValues] = useState(["Graduate"]);
    return (
      <ExtensionShell
        branding={{
          name: "My extension",
          subtitle: "Consumer-supplied branding",
          logo: (
            <span className="brand-asset" aria-hidden="true">
              ◆
            </span>
          ),
        }}
        version="1.0.0"
        beta
        tabs={tabs}
        activeTab={active}
        onTabChange={setActive}
        reviewUrl="https://chromewebstore.google.com/detail/bgnkdbccmhkocfmpcdpaenlbilekjkfb/reviews"
        style={{ height: 600, width: 480, maxWidth: "100%" }}
      >
        <TabsContent value="filters">
          <FilterListEditor
            values={values}
            inputLabel="Keyword"
            onAdd={(value) => setValues([...values, value])}
            onRemove={(value) => setValues(values.filter((v) => v !== value))}
          />
        </TabsContent>
        <TabsContent value="settings">
          <SettingsSection
            title="Backup preferences"
            description="Save or restore your filters."
          >
            <Button variant="outline">Export</Button>
          </SettingsSection>
        </TabsContent>
      </ExtensionShell>
    );
  },
  play: async ({ canvas }) => {
    await expect(canvas.getByLabelText("Beta build")).toBeInTheDocument();
    await userEvent.click(canvas.getByRole("tab", { name: "Settings" }));
    await expect(
      canvas.getByRole("heading", { name: "Backup preferences" }),
    ).toBeInTheDocument();
  },
};
export const LoadingAndSaveError: Story = {
  render: () => (
    <ExtensionShell
      version="1.0.0"
      reviewUrl={null}
      branding={{ name: "My extension" }}
      tabs={tabs}
      activeTab="filters"
      onTabChange={() => {}}
      loading
      status="Could not save preferences. Please try again."
      style={{ height: 600 }}
    />
  ),
};
export const InformationAndFeedback: Story = {
  render: () => (
    <div style={{ padding: 16, maxWidth: 480, fontFamily: "system-ui" }}>
      <InfoBanner>
        Jobs with application methods set to Hide will be hidden in your
        LinkedIn job search results.
      </InfoBanner>
      <SettingsSection
        title="Backup preferences"
        description="Save your preferences to a file, or restore a backup."
      >
        <Button variant="outline">Export</Button>
      </SettingsSection>
      <SaveStatus>Saved</SaveStatus>
    </div>
  ),
};
