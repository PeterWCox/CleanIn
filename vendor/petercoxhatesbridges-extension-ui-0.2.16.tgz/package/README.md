# `@petercoxhatesbridges/extension-ui`

Reusable React UI components for browser extensions.

## Install

```sh
pnpm add @petercoxhatesbridges/extension-ui
```

React 19 is a peer dependency. The package ships compiled JavaScript and CSS;
consumers do not need Tailwind to use the distribution.

## Components and exports

The package root exports:

- `Button` and `buttonClassName`
- `Tooltip`
- `Input`
- `IconDropdown`
- `FilterActionField` and `FilterAction` (Show/Fade/Hide dropdown with label, icon and info tooltip)
- `Tabs`, `TabsList`, `TabsTrigger` and `TabsContent`
- `Switch`
- `ShowHide`
- `FilterListEditor`
- `PreferencesShell`, `PreferencesHeader`, `PreferencesLayout`,
  `PreferencesNavigation`, `PreferencesContent` and `PreferencesFooter`

Import `styles.css` explicitly to apply the package styles:

```tsx
import { Button, Input } from "@petercoxhatesbridges/extension-ui";
import "@petercoxhatesbridges/extension-ui/styles.css";
```

Styles are opt-in. Component styles use scoped `ext-*` classes to avoid
collisions with host pages and applications. Theme values can be overridden
with CSS custom properties prefixed `--extension-ui-*`. Defaults follow the
TLDA theme, with legacy variable fallbacks for existing consumers.

## Tooltip

Wrap a button in `Tooltip` to show short text on hover or keyboard focus. Give
icon buttons an accessible name. When the tooltip adds information beyond that
name, it is exposed as an accessible description.

```tsx
<Tooltip text="Clear all saved filters">
  <Button variant="outline">Clear</Button>
</Tooltip>
```

The tooltip uses a hint popover where supported and falls back to the button's
title in browsers without the Popover API. Custom buttons must forward the
trigger's attributes and ref to the underlying button.

## IconDropdown

Pass a selected `value`, `onValueChange`, and options with `value`, `label`,
and optional decorative `icon` and `disabled` fields. Associate the dropdown
with a visible label using its `id` or `aria-labelledby`.

The dropdown uses the browser's native keyboard behavior. Browsers that
support customizable selects show each icon beside its label, including
the selected icon while closed. Other browsers display the text labels.

## FilterListEditor

`FilterListEditor` is controlled. The consumer owns its values and persistence;
the component does not contain domain rules or storage behavior.

Its props include:

- `values: string[]`
- `onAdd` and `onRemove` callbacks
- `inputLabel`, `placeholder` and `emptyText`
- `renderIcon` and `searchIcon`

## Stories

Source stories are published under the `./stories/*` package subpath exports.
TLDA can use these exports from its Storybook setup.

## Configured shell

`ExtensionShell` combines the lower-level layout components. Supply `branding`
(`name`, optional `accessibleName`, `subtitle`, and `logo` React node), required
`version` and `footerLinks`, optional `beta` or `buildLabel`, `tabs`, controlled `activeTab`/`onTabChange`,
and page content as children (normally `TabsContent`). Tab entries contain `id`,
`label`, optional `navigationLabel`, `icon`, `description`, `secondary`, and
`disabled`. Put secondary navigation such as Settings last; it follows the flexible spacer.

The version and footer remain visible while the content scrolls. Localhost
(including loopback addresses) automatically displays Beta; consumers pass `beta`
for unpacked development builds that use extension URLs.

`footerLinks` accepts `href`, `label`, and optional `icon`. Optional `header`,
`navigation`, `heading`, and `footer` slots replace those regions. `loading` and
`loadingText` control the loading message; `status` supplies polite live feedback.
The consumer obtains version/build metadata and owns Chrome APIs, persistence,
and save/retry handling. TLDA intentionally suppresses its routine Saved text.

`InfoBanner` renders an accessible note with a default circled information icon
and consumer content. `SettingsSection` accepts optional `title` and `description`
and arbitrary controls as children. `SaveStatus` renders a polite status message.

Common theme overrides include `--extension-ui-brand`, `--extension-ui-action`,
`--extension-ui-action-surface`, `--extension-ui-nav-surface`,
`--extension-ui-primary`, `--extension-ui-primary-foreground`,
`--extension-ui-font`, `--extension-ui-heading-font`, and `--extension-ui-ring`.
Apply these to a shell or a containing element, without changing global `:root`.

## Common footer

`ExtensionShell` takes `reviewUrl` and renders the shared **Review** and **About me** footer. Only the Chrome Web Store review URL varies between extensions. About me always points to Peter Cox's LinkedIn profile. Pass `null` while an extension is unpublished; Review remains visible but unavailable. Labels, icons and the creator destination belong to the shared package, not each app. The older `footerLinks` and `footer` props remain deprecated compatibility options.

## Shared settings and backups

`SettingsRow` provides a label, optional description and icon, and a consumer-owned control.
`ExtensionShell` defaults to vertical navigation. Call `configureExtensionSurface("popup")`
at the popup entry point for the standard 480 × 600 layout, or use `"panel"` / `"page"`
for a resizable extension surface. These helpers contain no Chrome APIs.

`BackupSection` provides export, immediate restore after file selection, and failure feedback.
Pass a stable `extensionId`, display name, version, and async `exportData` / `importData`
callbacks. Exports use the versioned `petercox-extension-backup` JSON envelope and are
portable between development and store builds of the same extension. Another extension's
backup and unsupported format versions are rejected before the import callback runs.

The consumer validates its own data and owns storage, save serialization and side effects.
The import callback must reject on failure; it runs immediately after the selected file passes validation.
An optional `parseLegacy` callback supports existing app-specific backup files. Chrome
runtime IDs, live sessions and storage implementations do not belong in the shared package.

The shared About me link uses the bundled Peter Cox avatar. It does not fetch an image from LinkedIn or require per-extension assets.

## 0.2.14

Includes compact tooltips, a welcome and onboarding wizard with save retry,
and compact Show/Hide or Hide/Fade choices. Onboarding state stays with the
consumer; TLDA persists whether setup is pending in extension storage.
