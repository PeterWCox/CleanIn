import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, fn, userEvent } from "storybook/test";
import { OnboardingWizard } from "../dist/index.js";
import "../dist/styles.css";
const meta = {
  title: "Extension UI/Onboarding wizard",
  component: OnboardingWizard,
  args: {
    header: { branding: { name: "Example extension" }, version: "1.0.0" },
    welcome: { title: "Welcome", description: "Choose your preferences." },
    steps: [{ title: "Working preferences", content: <p>Show the jobs you want to see.</p> }],
    onFinish: fn(),
    onSkip: fn(),
  },
} satisfies Meta<typeof OnboardingWizard>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Welcome: Story = {};
export const Finish: Story = {
  play: async ({ canvas, args }) => {
    await userEvent.click(canvas.getByRole("button", { name: "Start setup" }));
    await expect(canvas.getByRole("heading", { name: "Working preferences" })).toHaveFocus();
    await userEvent.click(canvas.getByRole("button", { name: "Finish" }));
    await expect(args.onFinish).toHaveBeenCalled();
  },
};
export const Skip: Story = {
  play: async ({ canvas, args }) => {
    await userEvent.click(canvas.getByRole("button", { name: "Skip setup" }));
    await expect(args.onSkip).toHaveBeenCalled();
  },
};
