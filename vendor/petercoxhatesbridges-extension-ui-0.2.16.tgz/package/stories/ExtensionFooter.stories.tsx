import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, waitFor } from "storybook/test";
import { ExtensionFooter } from "../dist/index.js";
import "../dist/styles.css";

const meta = {
  title: "Extension UI/Extension footer",
  component: ExtensionFooter,
  decorators: [
    (Story) => (
      <div
        className="ext-preferences-shell"
        style={{ height: 80, width: 480, maxWidth: "100%" }}
      >
        <Story />
      </div>
    ),
  ],
} satisfies Meta<typeof ExtensionFooter>;
export default meta;
type Story = StoryObj<typeof meta>;
export const Published: Story = {
  args: {
    reviewUrl:
      "https://chromewebstore.google.com/detail/bgnkdbccmhkocfmpcdpaenlbilekjkfb/reviews",
  },
  play: async ({ canvas }) => {
    await expect(canvas.getByRole("link", { name: "Review" })).toHaveAttribute(
      "href",
      "https://chromewebstore.google.com/detail/bgnkdbccmhkocfmpcdpaenlbilekjkfb/reviews",
    );
    await expect(
      canvas.getByRole("link", { name: "About me" }),
    ).toHaveAttribute("href", "https://www.linkedin.com/in/peter-w-cox");
    const creator = canvas.getByRole("link", { name: "About me" });
    await expect(creator.querySelector("img")).toHaveAttribute(
      "src",
      expect.stringMatching(/^data:image\/png;base64,/),
    );
    await waitFor(() => {
      const image = creator.querySelector("img");
      expect(image?.complete && image.naturalWidth > 0).toBe(true);
    });
  },
};
export const Unpublished: Story = {
  args: { reviewUrl: null },
  play: async ({ canvas }) => {
    await expect(canvas.getByRole("link", { name: "Review" })).toHaveAttribute(
      "aria-disabled",
      "true",
    );
    await expect(
      canvas.getByRole("link", { name: "Review" }),
    ).not.toHaveAttribute("href");
    await expect(
      canvas.getByRole("link", { name: "About me" }),
    ).toHaveAttribute("href", "https://www.linkedin.com/in/peter-w-cox");
  },
};
