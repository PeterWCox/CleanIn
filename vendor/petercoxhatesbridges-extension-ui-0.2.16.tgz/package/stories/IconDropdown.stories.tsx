import * as React from "react";
import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, userEvent } from "storybook/test";
import { IconDropdown, type IconDropdownOption } from "../dist/index.js";
import "../dist/styles.css";

type Theme = "light" | "system" | "dark";

const options: readonly IconDropdownOption<Theme>[] = [
  { value: "light", label: "Light", icon: <span>○</span> },
  { value: "system", label: "System", icon: <span>◐</span> },
  { value: "dark", label: "Dark", icon: <span>●</span> },
];

const meta = {
  title: "Extension UI/Icon dropdown",
  component: IconDropdown,
} satisfies Meta<typeof IconDropdown>;

export default meta;
type Story = StoryObj<typeof meta>;

export const ThemePicker: Story = {
  render: function Example() {
    const [value, setValue] = useState<Theme>("system");
    return (
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <label htmlFor="theme">Theme</label>
        <IconDropdown
          id="theme"
          name="theme"
          options={options}
          value={value}
          onValueChange={setValue}
        />
      </div>
    );
  },
  play: async ({ canvas }) => {
    const dropdown = canvas.getByRole("combobox", { name: "Theme" });
    await expect(dropdown).toHaveValue("system");
    await userEvent.selectOptions(dropdown, "dark");
    await expect(dropdown).toHaveValue("dark");
  },
};
