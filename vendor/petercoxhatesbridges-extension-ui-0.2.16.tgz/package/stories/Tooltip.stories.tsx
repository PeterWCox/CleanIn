import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, userEvent, waitFor } from "storybook/test";
import { Button, Tooltip } from "../dist/index.js";
import "../dist/styles.css";

const meta = {
  title: "Extension UI/Tooltip",
  component: Tooltip,
  parameters: { layout: "centered" },
} satisfies Meta<typeof Tooltip>;
export default meta;

type Story = StoryObj<typeof meta>;

export const Short: Story = {
  args: {
    text: "Save",
    children: <Button size="icon" aria-label="Save">✓</Button>,
  },
};

export const Long: Story = {
  args: {
    text: "Restore a previously exported backup to replace the filters and settings currently saved in this browser.",
    children: <Button variant="outline">Restore backup</Button>,
  },
};

export const ViewportEdges: Story = {
  ...Long,
  parameters: { layout: "fullscreen" },
  render: ({ text }) => (
    <div style={{ display: "flex", justifyContent: "space-between", padding: 2 }}>
      <Tooltip text={text}>
        <Button variant="outline">Import</Button>
      </Tooltip>
      <Tooltip text={`${text} Check the file first.`}>
        <Button variant="outline">Restore</Button>
      </Tooltip>
    </div>
  ),
  play: async ({ canvas, args }) => {
    for (const [name, hint] of [
      ["Import", args.text],
      ["Restore", `${args.text} Check the file first.`],
    ] as const) {
      const button = canvas.getByRole("button", { name });
      const tooltip = canvas.getByText(hint);
      // Synthetic pointer events do not activate native interest invokers.
      const native = button.hasAttribute("interestfor");
      if (native) tooltip.showPopover({ source: button });
      else await userEvent.hover(button);
      await waitFor(() => {
        expect(tooltip).toBeVisible();
        const bounds = tooltip.getBoundingClientRect();
        expect(bounds.left).toBeGreaterThanOrEqual(0);
        expect(bounds.right).toBeLessThanOrEqual(tooltip.ownerDocument.documentElement.clientWidth);
        expect(bounds.top).toBeGreaterThan(button.getBoundingClientRect().bottom);
      }, { timeout: 2000 });
      if (native) tooltip.hidePopover();
      else await userEvent.unhover(button);
    }
  },
};

export const Keyboard: Story = {
  ...Long,
  parameters: {
    docs: { description: { story: "Tab to Restore backup, then press Escape to dismiss the tooltip while keeping focus on the button." } },
  },
  play: async ({ canvas, args }) => {
    const button = canvas.getByRole("button", { name: "Restore backup" });
    const tooltip = canvas.getByText(args.text);
    await userEvent.tab();
    await expect(button).toHaveFocus();
    if (!button.hasAttribute("interestfor")) {
      await waitFor(() => expect(tooltip).toBeVisible());
      await userEvent.keyboard("{Escape}");
      await waitFor(() => expect(tooltip).not.toBeVisible());
      await expect(button).toHaveFocus();
    }
  },
};
