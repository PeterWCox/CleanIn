import * as React from "react";
import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, userEvent } from "storybook/test";
import { VisibilityChoice } from "../dist/index.js";
import "../dist/styles.css";
const meta = { title: "Extension UI/Visibility choice", component: VisibilityChoice } satisfies Meta<typeof VisibilityChoice>;
export default meta;
type Story = StoryObj<typeof meta>;
export const HideAndFade: Story = {
  render: function Example() {
    const [visible, setVisible] = useState(true);
    return <VisibilityChoice icon={<span>◉</span>} label="Filtered jobs" subject="filtered jobs" visible={visible} showLabel="Fade" onChange={setVisible} />;
  },
  play: async ({ canvas }) => {
    await userEvent.click(canvas.getByRole("button", { name: "Hide filtered jobs" }));
    await expect(canvas.getByRole("button", { name: "Hide filtered jobs" })).toHaveAttribute("aria-pressed", "true");
  },
};
